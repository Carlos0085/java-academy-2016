package inheritance;

public class Novel extends Book{

	public Novel(String name, Author author, double price) {
		super(name, author, price);
		// TODO Auto-generated constructor stub
	}
	public Novel(String name, Author author, double price, int qty) {
		super(name, author, price,qty);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String getInfo(){
		String info = "This is a novel written by " + author.getName();
		return info;
	}
	
	

}

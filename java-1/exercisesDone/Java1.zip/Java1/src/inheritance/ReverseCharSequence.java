package inheritance;

public class ReverseCharSequence implements CharSequence {
	private final CharSequence string;
	private char[] original;
	private char[] reversed;
	
	public ReverseCharSequence(CharSequence string)
    {
        this.string = string;
//        string.
    }
	
	public char[] reverseString() {
		String temp = string.toString();
		original = temp.toCharArray();
		reversed = new char[original.length];
		int j=0;
		for (int i=original.length; i>0; i--){
			reversed[j]= original[i-1];
			j++;
		}
		return reversed;
	}

	@Override
	public char charAt(int index) {
		// TODO Auto-generated method stub
		return string.charAt(index);
	}

	@Override
	public int length() {
		// TODO Auto-generated method stub
		return string.length();
	}

	@Override
	public CharSequence subSequence(int start, int end) {
		// TODO Auto-generated method stub
		return string.subSequence(start, end);
	}

}

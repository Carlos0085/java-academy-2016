package ecosystem;

public class Dog extends Animal {
	private String breed;
	private boolean vaccines;
	
	public Dog(boolean awake, int age, String breed) {
		super(awake, age);
		this.breed = breed;
		
	}

	public boolean getVaccines() {
		return vaccines;
	}

	public void setVaccines(boolean vaccines) {
		this.vaccines = vaccines;
	}

	@Override
	public void talk() {
		System.out.println("Wuau!!");
	}
}

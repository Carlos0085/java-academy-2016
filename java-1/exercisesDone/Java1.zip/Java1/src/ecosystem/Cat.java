package ecosystem;

public class Cat extends Animal{

	public Cat(boolean awake, int age) {
		super(awake, age);
	}
	
	@Override
	public void talk() {
		System.out.println("Miau!!");
	}

}

package ecosystem;

public class Animal {
	protected boolean awake;
	protected int age;
	
	public Animal (){
		awake= true;
		age=1;
	}
	public Animal(boolean awake, int age){
		this.awake = awake;
		this.age= age;
		
	}
	
	public void eat() {
		System.out.println("I am eating");
	}
	public void talk() {
		System.out.println("I am talking");
	}


}

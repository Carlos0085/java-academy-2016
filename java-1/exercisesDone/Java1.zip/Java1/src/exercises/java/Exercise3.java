package exercises.java;

import ecosystem.Animal;
import ecosystem.Cat;
import ecosystem.Dog;

public class Exercise3 {
	//classes

	public static void main(String[] args) {
		Animal animal = new Animal();//default constructor
		Animal animal2= new Animal(true,3);
		Cat cat = new Cat(true, 2);
		Dog dog = new Dog(true, 1, "Poodle");//overloading constructor for animal
		
		dog.setVaccines(true);// this must be set with method since variable is private;
	}

}

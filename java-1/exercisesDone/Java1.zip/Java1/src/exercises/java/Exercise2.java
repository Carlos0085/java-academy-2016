package exercises.java;

public class Exercise2 {
	int scopeClass;

	public static void main(String[] args) {
		int scopeMethod;
		byte b;
		short s;
		long l;
		float fl;
		double db;
		boolean bl;
		char ch;
		String words; //not considered primitive

		for (int i = 0; i < 10; i++) {
			int scopeLoop;
		}
		
		//basic operators usage
		int sum = 10+5;
		int sub = sum-1;
		int mul = sub * 2;
		int div = mul / 2;
		int mod = div % 4;
		
//		Operators
//		math:
//		-
//		+
//		*
//		/
//		%
//		++
//		--
		
//		Assignment:
//		=
//		+=
//		-=
//		*=
//		/=
//		%=
		
//		Relational:
//		>
//		<>
//		<=
//		>=
//		==
//		!=
		
		String asPrimitive = "Hello";
		String asObject = new String("Hello");
		
		int[] array = new int[10];
		int[] array2= {1,2,3,4};
		array [1]= 10;
		array[2]=array[1]+array2[2];
			

	}

}

package exercises.java;

public class Exercise4 {
	//control statements

	public static void main(String[] args) {
//		example1();
//		example2();
//		int result = example3();
//		foo();//example 4

	}
	public static void example1() {//this will return the first 4 hours
		int th = 0;
		int daf = 4;
		for (int i=1; i<25;i++){
			th++;//made this correction becase th=th++ made no sense for me
			if(th > daf){
				break;
			}
			System.out.println("Fishing for hour "+ i);
		}
	}
	public static void example2() {// this will return camping and fishing for the first 5 days 
		//camping for the rest  of the days
		int tdc = 0;
		int daf = 5;
		for (int i=1; i<8; ++i){
			System.out.println("\nDay "+ i + ": camping");
			tdc++;//made this correction just as in previous exercise
			if(tdc > daf){
				continue;
			}
			System.out.println("and Fishing");
		}
		
	}
	public static int example3() {//a simple return for de result of 3+1
		return 3+1;

	}
	public static void foo() {// result is b=2
		int b = 1;
		b++;
	}
}

package exercises.java;

import inheritance.Author;
import inheritance.Book;
import inheritance.Novel;
import inheritance.ReverseCharSequence;

public class Exercise5 {
	//inheritance
	//this class will be used to test the public methods
	
	public static void main(String[] args) {
		Author author = new Author ("C.Fuentes", "cfuentes@hotmail.com",'M');
		Book book = new Book("Aura", author,9.99, 10);
		
		System.out.println(book);//to string method
		book.setPrice(19.99);//public method
		book.setQty(15);//public method
		System.out.println(book.getInfo());//public method
		System.out.println(book);//price and quantity have increased
		
		///polymorphism
		Author author2 = new Author ("W.Shakespeare", "", 'M');
		Book novela = new Novel("Hamlet",author2, 10.99, 25);
		// since it is inherited from book, it can make reference to a novel
		//but get info will take method from novel class
		System.out.println(novela.getInfo());
		
		//intefaces
		ReverseCharSequence charsequence = new ReverseCharSequence("hello"); 
		System.out.println(charsequence.reverseString());
		System.out.println(charsequence.charAt(2));
		System.out.println(charsequence.length());
		System.out.println(charsequence.subSequence(2, 4));
//		CharSequence text = "Hello";
//		System.out.println(text.toString().toCharArray().toString());

	}

}

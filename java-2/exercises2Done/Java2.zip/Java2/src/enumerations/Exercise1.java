package enumerations;

public class Exercise1 {

	public static void main(String[] args) {
		System.out.println(Color.BLUE);
	}
	

}

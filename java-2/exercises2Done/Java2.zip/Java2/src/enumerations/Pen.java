package enumerations;

public class Pen{
	Color color;
	
	public Pen(Color color){
		this.color=color;
	}
	public Color getColor(){
		return color;
	}
	
}

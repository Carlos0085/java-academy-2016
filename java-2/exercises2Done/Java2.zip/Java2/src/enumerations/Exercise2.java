package enumerations;

public class Exercise2 {

	public static void main(String[] args) {
		Pen pen = new Pen(Color.BLUE);
		
		switch(pen.getColor()){
		case BLACK:
			System.out.println("This pen is has " + pen.getColor().getColor() +" ink");
			break;
		case RED:
			System.out.println("This pen is has " + pen.getColor().getColor() +" ink");
			break;
		case BLUE:
			System.out.println("This pen is has " + pen.getColor().getColor() +" ink");
			break;
		default:
			System.out.println("This pen has no ink");
			break;
		}

	}

}

package enumerations;

public class Exercise3 {

	public static void main(String[] args) {
		for (Color color : Color.values()) {
			System.out.println(color);
		}
	}

}

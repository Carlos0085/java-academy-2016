package collections;
import java.util.*;

public class Exercise3 {

	public static void main(String[] args) {

		List<String> list = Arrays.asList(args);
		Collections.shuffle(list);

		list.stream().forEach(item->System.out.println(item));

		for (String element: list) {
			System.out.println(element);
		}

		System.out.println();
	}
}

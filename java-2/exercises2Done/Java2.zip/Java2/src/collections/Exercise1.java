package collections;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Exercise1 {

	public static void main(String[] args) {
		Set<Integer> grades = new HashSet<Integer>();
		Map<String, String> dictionary = new HashMap<String, String>();
		grades.add(1);
		grades.add(2);
		
		dictionary.put("abase", "lower; degrade; humiliate.");
		dictionary.put("abash", "embarrass");
		dictionary.put("abate", "to reduce in amount");
		// collections can be easily iterated through the use of for- each
		
		for (Integer t: grades){
			System.out.println(t);
		}
		
		System.out.println("List of definitions in dictionary.");
		for (Map.Entry<String, String> word : dictionary.entrySet()){
			System.out.println(word.getKey() + ": " + word.getValue());
		}

	}

}

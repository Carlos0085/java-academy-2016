package collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Exercise2 {

	public static void main(String[] args) {
//		Set names = new HashSet(); // the fastest set
//		Set names = new TreeSet(); // this kind of set will order the elements in the collection
		Set names = new LinkedHashSet();// saves the order of insertion.
		names.add("Jake");
		names.add("Robert");
		names.add("Marisa");
		names.add("Kasey");
		System.out.println(names);

	}

}

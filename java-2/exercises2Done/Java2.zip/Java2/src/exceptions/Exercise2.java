package exceptions;

public class Exercise2 {

	public static void main(String[] args) {
		
		try
		{
			int x = 0;
			int y = 5 / x;
		}
		/*catch (Exception e)
		{
			System.out.println("Exception");
		}*/
		catch (ArithmeticException ae)// exception before is too general and is already catching 
		//the exception
		// so most close answer would be C. Compilation fails.
		{
			System.out.println(" Arithmetic Exception");
		}
		System.out.println("finished");

	}

}

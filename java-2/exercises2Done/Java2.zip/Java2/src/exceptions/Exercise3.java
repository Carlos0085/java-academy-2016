package exceptions;

public class Exercise3 {

// Finally will execute no matter what so both prints will appear on screen.
	public static void main(String args[])
	{
		try
		{
			System.out.print("Hello world ");
		}
		finally
		{
			System.out.println("Finally executing ");
		}
	}

}

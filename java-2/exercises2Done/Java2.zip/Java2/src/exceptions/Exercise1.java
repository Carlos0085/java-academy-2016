package exceptions;

import java.io.FileReader;
import java.io.IOException;

public class Exercise1 {

	public static void main(String[] args) {
		FileReader fr = null; 
		// the variable only existed in the first try so i declare it outside for the code
		//to work
		try {
//			FileReader fr = new FileReader("data.txt");
			fr = new FileReader("data.txt");
		}
		catch(IOException e){}
		try {
			fr.close();
		}
		catch(IOException e){}
	}

}


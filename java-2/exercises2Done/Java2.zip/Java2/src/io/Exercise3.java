package io;

import java.io.FileReader;
import java.io.InputStreamReader;

public class Exercise3 {

	public static void main(String[] args) {
//		new InputStreamReader(new FileInputStream("data"));
//		CORRECT but requires try-catch
		
//		new InputStreamReader(new FileReader("data"));
//		file reader is no parameter for inpustreamReader
		
//		new InputStreamReader(new BufferedReader("data"));
//		buffered reader is not a parameter for inputstreamreader
		
//		new InputStreamReader("data");
//		inputstreamreader does not receive data as a parameter nor any "raw" string.
		
//		new InputStreamReader(System.in);
//		CORRECT

	}

}

package io;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exercise1 {

	public static void main(String[] args) {
		FileReader reader = null;
		BufferedReader bReader = null;
		//		EReader eReader = null;
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Give a letter to search for in the text file...");
			String input = br.readLine();
			char letter[] = input.toCharArray(); 
			reader = new FileReader("E:\\Java2\\sampleText.txt");
			bReader = new BufferedReader(reader);
			//			 eReader = new EReader(bReader);
			String line;
			int counter = 0;
			while ((line=bReader.readLine()) != null){

				for( int i=0; i<line.length(); i++ ) {
					if( line.charAt(i) == letter[0] ) {
						counter++;
					} 
				}
			}
			System.out.println("The total numer of '"+letter[0]+"'s was: " + counter);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

package io;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Exercise2 {

	public static void main(String[] args) {
//		Path path = Paths.get(("E:\\Java2\\NewDirectory\\"));
		
		
		File file = new File("E:\\Java2\\NewDirectory\\sample.txt");
		file.getParentFile().mkdirs();
		System.out.println("Directory Created Succesfully!!");
		
//		try {
//			Files.createDirectory(path);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

	}

}
